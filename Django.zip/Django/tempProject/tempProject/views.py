from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    params={'name':"Harsh","Year":"2027"}
    return render(request, 'index.html',params)    # passing details to the page 
                                                    # here request is included while rendering an html page

def form_details(request):
    # Get the text
    text = request.POST.get('text','default')
    print(text)
    check=request.POST.get('check1','off')
    print(check)


    return HttpResponse(f'{text} {check}')
