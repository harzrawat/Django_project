# I have created this file - Harsh
from django.http import HttpResponse
from django.shortcuts import render

def index(request):   # request is by deafual argument
    return HttpResponse('''<h1>Hello Harsh</h1>  <br> <a href="about">Know about Harsh</a>''')

def about(request):   # request is by deafual argument
    return HttpResponse("Harsh is a student @Sitare")

def team(request):
    return about(request)

def more(request):
    return HttpResponse('''<h1>Get Back</h1> <br> <a href='/'>Back</a>''' )    # by this we can get back to home page

def func1(request):
    return HttpResponse('''<a href="about">Know about Harsh</a>''')   # this is not working , I want to get back to about page from here
